import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm, Form, FormGroup, FormControl, Validators } from '@angular/forms';
import { Place } from '../../../models/place.model';
import { Order } from '../../../models/order.model';
import { NavController } from '@ionic/angular';
import { BrowseService } from '../browse.service';
import { PlaceDetailsService } from '../place-details/place-details.service';

@Component({
  selector: 'app-place-details',
  templateUrl: './place-details.page.html',
  styleUrls: ['./place-details.page.scss'],
})
export class PlaceDetailsPage implements OnInit {

  place: Place[] = [];
  items: [];
  order: Order = {} as any;
  merchantId: string;
  form: FormGroup;
  constructor(
    private route: ActivatedRoute,
    private navCtrl: NavController,
    private browseSvc: BrowseService,
    private detailSvc: PlaceDetailsService) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      if(!params.has('browseId')){
        this.navCtrl.navigateBack('/places/tabs/browse')
        return
      }
      this.merchantId = params.get('browseId')
      this.browseSvc.getPlace(this.merchantId).subscribe((places) => {
        this.place.push(places);
        console.log(this.place);
      })
    })

    this.form = new FormGroup({
      Plastik: new FormControl(0, {
        updateOn: "change"
      }),
      Koran: new FormControl(0, {
        updateOn: "change"
      }),
      Botol: new FormControl(0, {
        updateOn: "change"
      }),
      Kertas: new FormControl(0, {
        updateOn: "change"
      }),
    })
  }

  saveOrder(){
    const user = "yupnsapYldCe7Om6wAFh";
    const merchant = "A7M2Y1CDPkfZDqq0EApS";
    // this.form.value.forEach(element => {
    //   // if("Kertas" == element){
    //   //   this.order.user = user
    //   //   this.order.jenisSampah = element
    //   //   this.order.qty = this.form.value.Kertas
    //   // }
    //   console.log(element)
    //});
    this.order.user = user
    this.order.merchant = this.merchantId
    this.order.status = "submitted"
    
    for(let jenis in this.form.value){
      if("Kertas" == jenis){
        this.order.jenisSampah = jenis
        this.order.qty = this.form.value.Kertas
        this.detailSvc.addOrder(this.order)
      }else if("Botol" == jenis){
        this.order.jenisSampah = jenis
        this.order.qty = this.form.value.Botol
      }else if("Koran" == jenis){
        this.order.jenisSampah = jenis
        this.order.qty = this.form.value.Koran
      }else if("Plastik" == jenis){
        this.order.jenisSampah = jenis
        this.order.qty = this.form.value.Plastik
      }
      const x = this.detailSvc.addOrder(this.order)
      console.log(x)
    }
  }

}
